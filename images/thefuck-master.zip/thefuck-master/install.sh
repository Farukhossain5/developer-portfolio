#!/bin/sh

echo "Installation script is deprecated!"
echo "For installation instruction please visit https://github.com/nvbn/thefuck"
